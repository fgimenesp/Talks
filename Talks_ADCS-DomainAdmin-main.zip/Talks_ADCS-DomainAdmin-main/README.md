# Talks_ADCS-DomainAdmin
This is my new repository thats contain all slides of talks of "H2HC and Redteam Village EkoParty"

#PoC

https://youtu.be/ZSUQB9_SEJw

If have some douths or question let me know

@donotouchplease
